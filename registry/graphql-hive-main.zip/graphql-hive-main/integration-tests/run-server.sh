#!/bin/sh

set -e

npm install -g file:server.tgz
server
