#!/bin/sh

set -e

npm install -g file:storage.tgz
storage
