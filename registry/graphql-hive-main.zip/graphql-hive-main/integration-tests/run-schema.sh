#!/bin/sh

set -e

npm install -g file:schema.tgz
schema
