#!/bin/sh

set -e

node cdn.js
