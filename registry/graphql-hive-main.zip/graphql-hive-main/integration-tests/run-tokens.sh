#!/bin/sh

set -e

npm install -g file:tokens.tgz
tokens
