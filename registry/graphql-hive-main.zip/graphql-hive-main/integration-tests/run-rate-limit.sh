#!/bin/sh

set -e

npm install -g file:rate-limit.tgz
rate-limit
