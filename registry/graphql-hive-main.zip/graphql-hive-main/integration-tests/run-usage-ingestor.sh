#!/bin/sh

set -e

npm install -g file:usage-ingestor.tgz
usage-ingestor
