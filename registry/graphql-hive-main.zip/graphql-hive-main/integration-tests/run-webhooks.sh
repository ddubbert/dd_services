#!/bin/sh

set -e

npm install -g file:webhooks.tgz
webhooks
