#!/bin/sh

set -e

npm install -g file:usage-estimator.tgz
usage-estimator
