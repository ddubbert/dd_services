#!/bin/sh

set -e

npm install -g file:usage.tgz
usage
