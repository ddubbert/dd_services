# Security Policy

## Reporting a Vulnerability

Please report vulnerabilities to `contact@the-guild.dev`.
