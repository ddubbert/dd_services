# @graphql-hive/core

## 0.2.2

### Patch Changes

- ad66973: Bump

## 0.2.1

### Patch Changes

- 0a5dbeb: Point to graphql-hive.com

## 0.2.0

### Minor Changes

- ac9b868c: Support GraphQL v16

## 0.1.0

### Minor Changes

- d7348a3: Hide literals and remove aliases

### Patch Changes

- d7348a3: Pick operation name from DocumentNode

## 0.0.5

### Patch Changes

- c6ef3d2: Bob update

## 0.0.4

### Patch Changes

- 4a7c569: Share operation hashing

## 0.0.3

### Patch Changes

- 6b74355: Fix sorting

## 0.0.2

### Patch Changes

- 094c861: Normalization of operations
