import HistoryPage from '../history';

export default HistoryPage;
