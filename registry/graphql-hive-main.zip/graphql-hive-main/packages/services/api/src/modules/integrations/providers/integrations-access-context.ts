export enum IntegrationsAccessContext {
  Integrations,
  ChannelConfirmation,
  SchemaPublishing,
}
