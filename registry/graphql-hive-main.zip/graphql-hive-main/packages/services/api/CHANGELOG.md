# @hive/api

## 0.0.1

### Patch Changes

- 8035861: Stop masking GraphQL syntax errors within `Mutation.schemaPublish`.
