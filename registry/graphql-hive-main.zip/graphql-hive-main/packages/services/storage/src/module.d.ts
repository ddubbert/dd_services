declare module 'slonik-interceptor-query-logging';
