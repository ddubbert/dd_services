--commit-project-id (down)

ALTER TABLE public.commits DROP COLUMN project_id;