ALTER TABLE public.commits
  DROP COLUMN get_started_creating_project,
  DROP COLUMN get_started_publishing_schema,
  DROP COLUMN get_started_checking_schema,
  DROP COLUMN get_started_inviting_members,
  DROP COLUMN get_started_reporting_operations,
  DROP COLUMN get_started_usage_breaking;
