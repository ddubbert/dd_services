DROP TABLE public.organizations_billing;
ALTER TABLE public.organizations DROP COLUMN plan_name;
