--alerts (down)

DROP TYPE IF EXISTS alert_channel_type;
DROP TYPE IF EXISTS alert_type;
DROP TABLE IF EXISTS public.alert_channels;
DROP TABLE IF EXISTS public.alerts;