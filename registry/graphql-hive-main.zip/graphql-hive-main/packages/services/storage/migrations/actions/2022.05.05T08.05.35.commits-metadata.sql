ALTER TABLE public.commits
  ADD COLUMN "metadata" text
;
