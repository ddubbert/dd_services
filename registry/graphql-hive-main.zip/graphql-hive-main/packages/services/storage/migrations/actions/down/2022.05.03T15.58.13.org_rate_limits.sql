ALTER TABLE public.organizations DROP COLUMN limit_operations_monthly;
ALTER TABLE public.organizations DROP COLUMN limit_schema_push_monthly;
ALTER TABLE public.organizations DROP COLUMN limit_retention_days;
