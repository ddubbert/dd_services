DELETE FROM public.tokens WHERE deleted_at IS NOT NULL;
