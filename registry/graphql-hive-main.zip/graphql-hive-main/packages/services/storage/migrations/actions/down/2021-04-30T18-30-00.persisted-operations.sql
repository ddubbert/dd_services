--persisted_operations (down)

DROP TABLE IF EXISTS public.persisted_operations;
DROP TYPE  IF EXISTS operation_kind;