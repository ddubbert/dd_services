--tokens (up)

ALTER TABLE public.tokens DROP COLUMN last_used_at;