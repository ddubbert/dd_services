--activities (down)

DROP TABLE IF EXISTS activities;