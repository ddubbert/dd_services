ALTER TABLE public.commits
  DROP COLUMN "metadata"
;
